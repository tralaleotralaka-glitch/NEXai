# NEXAI Android project

This project packages the supplied NEXAI HTML app in a native Android WebView.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload all files and folders from this project.
3. Open the repository's **Actions** tab.
4. Select **Build NEXAI APK** and press **Run workflow** (or push to `main`).
5. When the run finishes, open it and download the **NEXAI-APK** artifact.
6. Inside the downloaded ZIP is `app-debug.apk`.

This is a debug APK for testing, not a Play Store release build.
The current NEXAI assistant works locally with built-in response templates; it is not connected to a real AI model.
